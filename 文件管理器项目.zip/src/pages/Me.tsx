import {
  User,
  Settings,
  Palette,
  Shield,
  HelpCircle,
  Info,
  Moon,
  Bell,
  Download,
  Star,
  Share2,
  LogOut
} from 'lucide-react';

const Me = () => {
  const menuItems = [
    { icon: Settings, label: '设置', color: 'text-blue-500' },
    { icon: Palette, label: '主题', color: 'text-purple-500' },
    { icon: Moon, label: '深色模式', color: 'text-indigo-500' },
    { icon: Bell, label: '通知', color: 'text-orange-500' },
    { icon: Shield, label: '隐私', color: 'text-green-500' },
    { icon: Download, label: '下载管理', color: 'text-cyan-500' },
    { icon: Star, label: '收藏', color: 'text-yellow-500' },
    { icon: Share2, label: '分享', color: 'text-pink-500' },
    { icon: HelpCircle, label: '帮助', color: 'text-teal-500' },
    { icon: Info, label: '关于', color: 'text-gray-500' },
  ];

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* 顶部 */}
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 px-4 pb-8 pt-4">
        <div className="flex items-center h-14">
          <h1 className="text-lg font-semibold text-white">我的</h1>
        </div>
        
        {/* 用户信息 */}
        <div className="flex items-center gap-4 mt-4">
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
            <User size={32} className="text-white" />
          </div>
          <div className="text-white">
            <p className="font-semibold text-lg">用户</p>
            <p className="text-blue-100 text-sm">手机文件管理器 v1.0</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* 统计卡片 */}
        <div className="px-4 -mt-4">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-blue-500">128</p>
                <p className="text-xs text-gray-500">文件</p>
              </div>
              <div className="border-x border-gray-200">
                <p className="text-2xl font-bold text-green-500">36</p>
                <p className="text-xs text-gray-500">文件夹</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-purple-500">5.2G</p>
                <p className="text-xs text-gray-500">总大小</p>
              </div>
            </div>
          </div>
        </div>

        {/* 菜单列表 */}
        <div className="mt-4">
          {menuItems.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="flex items-center gap-3 px-4 py-3 bg-white border-b border-gray-100 hover:bg-gray-50 cursor-pointer"
              >
                <div className={`p-2 rounded-lg ${item.color.replace('text-', 'bg-').replace('500', '100')}`}>
                  <Icon size={20} className={item.color} />
                </div>
                <span className="font-medium text-gray-700">{item.label}</span>
              </div>
            );
          })}
        </div>

        {/* 退出登录 */}
        <div className="p-4">
          <div className="flex items-center gap-3 px-4 py-3 bg-white rounded-xl border border-gray-100 hover:bg-red-50 cursor-pointer text-red-500">
            <div className="p-2 rounded-lg bg-red-100">
              <LogOut size={20} />
            </div>
            <span className="font-medium">退出</span>
          </div>
        </div>

        {/* 版本信息 */}
        <div className="text-center py-6 text-xs text-gray-400">
          <p>文件管理器 v1.0.0</p>
          <p className="mt-1">© 2024 All Rights Reserved</p>
        </div>
      </div>
    </div>
  );
};

export default Me;
